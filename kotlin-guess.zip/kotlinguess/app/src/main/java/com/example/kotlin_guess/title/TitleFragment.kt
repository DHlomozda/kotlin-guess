package com.example.kotlin_guess.title

import android.support.v4.app.Fragment

class TitleFragment: Fragment() {
}